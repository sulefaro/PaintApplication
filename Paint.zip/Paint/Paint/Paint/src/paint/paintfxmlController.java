package paint;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Slider;

public class paintfxmlController implements Initializable {
    
    @FXML
    private ColorPicker colorpicker; 
    
    @FXML
    private Canvas canvas;
    
    @FXML
    private Slider slider;
    
    
    
    boolean toolSelected = false;
    boolean b1Selected = false;
    boolean b2Selected = false;
    boolean b3Selected = false;
    boolean eraserSelected = false;
    boolean sliderSelected = false;

    GraphicsContext brushTool;
    
    
    int defaultWidth  = 686;
    int defaultHeight = 439;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        brushTool = canvas.getGraphicsContext2D();
        canvas.setOnMouseDragged(e -> {
 
            if(toolSelected && b1Selected)
                {
                double size = 10;
                double x = e.getX() - size / 2;
                double y = e.getY() - size / 2;
                brushTool.setFill(colorpicker.getValue());
                brushTool.fillRoundRect(x, y, size, size, size, size);

                }
            
            else if(toolSelected && b2Selected)
                {
                double size = 20;
                double x = e.getX() - size / 2;
                double y = e.getY() - size / 2;
                brushTool.setFill(colorpicker.getValue());
                brushTool.fillRoundRect(x, y, size, size, size, size);

                }
                        
            else if(toolSelected && b3Selected)
                {
                double size = 30;
                double x = e.getX() - size / 2;
                double y = e.getY() - size / 2;
                brushTool.setFill(colorpicker.getValue());
                brushTool.fillRoundRect(x, y, size, size, size, size);
                }

            else if(toolSelected && eraserSelected)
                {
                double size = slider.getValue();
                double x = e.getX() - size / 2;
                double y = e.getY() - size / 2;
                brushTool.clearRect(x, y, size, size);
                }
            
            else if(toolSelected)
                {

                    double size = slider.getValue();
                    //size = 50;
                    double x = e.getX() - size / 2;
                    double y = e.getY() - size / 2;
                    brushTool.setFill(colorpicker.getValue());
                    brushTool.fillRoundRect(x, y, size, size, size, size);
                }
            
        });
        
    }    
        
    @FXML
    public void clear(ActionEvent e)
    {
        brushTool.clearRect(0, 0, defaultWidth, defaultHeight);
    }
    
    @FXML
    public void toolselected(ActionEvent e)
    {
        toolSelected = true;
        sliderSelected = true;
        eraserSelected = false;
        b1Selected = false;
        b2Selected = false;
        b3Selected = false;
    }
    
    
    @FXML
    public void b1selected(ActionEvent e)
    {
        sliderSelected = false;
        eraserSelected = false;
        b1Selected = true;
        b2Selected = false;
        b3Selected = false;
    }
    
    @FXML
    public void b2selected(ActionEvent e)
    {
        sliderSelected = false;
        eraserSelected = false;
        b2Selected = true;
        b1Selected = false;
        b3Selected = false;
    }
    
    @FXML
    public void b3selected(ActionEvent e)
    {
        sliderSelected = false;
        eraserSelected = false;
        b3Selected = true;
        b1Selected = false;
        b2Selected = false;
    }
    
    @FXML
    public void eraserSelected(ActionEvent e)
    {
        sliderSelected = false;
        eraserSelected = true;
        b3Selected     = false;
        b1Selected     = false;
        b2Selected     = false;
        
    }
  
    @FXML
    public void sliderSelected(ActionEvent e)
    {
        sliderSelected = true;
        eraserSelected = false;
        b1Selected = false;
        b2Selected = false;
        b3Selected = false;
        
    }
    
}
